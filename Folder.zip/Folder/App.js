import React, { Component } from 'react';
import { BrowserRouter } from 'react-router-dom';
import './App.css';

import Nav from './Authenticate/Nav/Nav';

class App extends Component {

    render() {
     
        return (
            <BrowserRouter>
            <div align="center">
               <Nav/>
            </div>
            </BrowserRouter>

    );
  }
}

export default App;

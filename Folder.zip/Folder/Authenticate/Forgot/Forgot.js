import React from 'react';
import { Link } from 'react-router-dom';


const forgot = () => {
    return (
        <div className="Nav-component">
            <p> Please enter the temporary code you have been emailed to reset your password.</p>
            <p>  <input type='text' /></p>
            
            <p>Back to <Link to="/"> Login </Link> </p>

        </div>
    );
}

export default forgot;
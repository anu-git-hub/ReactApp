import React from 'react';
import { Route, Link } from 'react-router-dom';
import './Nav.css';

import Login from '.././Login/Login';
import Register from '.././Register/Register';
import Forgot from '.././Forgot/Forgot';

const nav = () => {
    return (
        <div className="Nav">
            <Link to="/"> Login </Link>
            <Link to="/createAcc"> Create Account </Link>
          
            <div>
                <Route path="/" exact render={Login} />
                <Route path="/createAcc" render={Register} />
                <Route path="/forgot" render={Forgot} />
            </div>
        </div>
    );
}

export default nav;
import React from 'react';
import {Link } from 'react-router-dom';

const register = () => {
    return (
        <div className= "Nav-component">            
            <p> Full Name* : <input type='text' /></p >
            <p>Organization* : <input type='text' /></p >
            <p>Email* : <input type='text' /></p >
            <p>Password *: <input type='text' /></p >
            <button >Create Account </button>  
            <p>Already have an account? <Link to="/"> Login </Link></p >
        </div>
    );
};

export default register;
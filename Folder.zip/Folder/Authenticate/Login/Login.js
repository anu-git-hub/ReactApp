import React from 'react';
import { Link } from 'react-router-dom';


const login = () => {
    return (
        <div className="Nav-component">
            <p> Email id : <input type='text' /></p>
            <p>  Password : <input type='text' /></p>
            <p>  <button >Submit</button> </p>

            <Link to="/forgot"> <p>Forgot your Password?</p> </Link>
            
        </div>
    );
}

export default login;
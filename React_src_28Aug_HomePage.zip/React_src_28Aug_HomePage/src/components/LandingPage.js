import React, { useState } from 'react';
import { Link } from 'react-router-dom';

import AppBar from '@material-ui/core/AppBar';
import Toolbar from '@material-ui/core/Toolbar';
import Tabs from '@material-ui/core/Tabs';
import Tab from '@material-ui/core/Tab';
import Button from '@material-ui/core/Button';
import Menu from '@material-ui/core/Menu';
import MenuItem from '@material-ui/core/MenuItem';
import Paper from '@material-ui/core/MenuItem';
import Grid from '@material-ui/core/Grid';
import Hidden from '@material-ui/core/Hidden';
import Typography from '@material-ui/core/Typography';

import logo from '../img/logo.svg';
import { makeStyles } from '@material-ui/styles';

const useStyles = makeStyles(theme => ({
    congImage: {
        height: "3em"
    },
    mainContainer: {
        marginTop: "5em",
        [theme.breakpoints.down("md")]: {
            marginTop: "3em"
        },
        [theme.breakpoints.down("xs")]: {
            marginTop: "2em"
        },

        width: "78em",
        [theme.breakpoints.down("md")]: {
            width: "21em"
        },
        [theme.breakpoints.down("xs")]: {
            width: "15em"
        },
        height: "35em",
        paddingTop : 0,
        position: "absolute",
        color: "primary",
        backgroundColor: "primary",
       
        border :"2px"
    },
    gridContainer: {
        marginTop: "0.1em",        
    }
   
}));


const LandingPage = () => {
    const classes = useStyles();
  
    return (
        <React.Fragment>
            <Grid container bgColor="primary" alignItems="center" justify="flex-start"
                direction="column"  
                className={classes.mainContainer} spacing={1} >
                <Grid item >
                    <img alt="congratulations image" className={classes.congImage} src={logo} />
                </Grid>
                <Grid item >
                    <Typography color="secondary" fontweight="bold" >
                        Congratulations! Welcome to the secure world.   You are now successfully registerd.                      
                    </Typography>
                    <Typography align="center" color="secondary" fontweight="bold" >
                        You are now successfully registerd.
                    </Typography>
                </Grid>
                <Grid item>
                    <Grid container
                        direction="row"
                        alignItems="center" spacing={10} className={classes.gridContainer} >
                        <Grid item>
                            <Grid container
                                direction="column"
                                justify="flex-start" alignItems="flex-start" spacing={3}>
                                <Grid item>
                                    <Button
                                         variant="contained"
                                        color="secondary"
                                        className={classes.button} >
                                        Long Button Text 1
                                    </Button>
                                </Grid>
                                <Grid item>
                                    <Button
                                        variant="contained"
                                        color="secondary"
                                        className={classes.button} >
                                        Button Text 2
                                    </Button>
                                </Grid>
                            </Grid>
                        </Grid>

                        <Grid item>
                            <Grid container
                                direction="column"
                                justify="center" alignItems="flex-start" spacing={3}>
                                <Grid item>
                                    <Typography color="black" fontweight="bold" >
                                        Get started with us
                                    </Typography>
                                
                                    <Typography color="secondary" fontweight="bold" >
                                        Link to our Guide
                                    </Typography>
                                </Grid>
                                <Grid item>
                                    <Typography color="secondary" fontweight="bold" >
                                        Text Link 2
                                    </Typography>

                                </Grid>
                            </Grid>

                        </Grid>

                    </Grid>

                </Grid>
            </Grid>
        </React.Fragment>
    );
}

export default LandingPage;
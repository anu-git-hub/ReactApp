import { createMuiTheme } from "@material-ui/core/styles";

const arcBlue = "#0B72B9";
const arcOrange = "#FFBA60";
const arcGrey = "#EDEDED";

const theme = createMuiTheme({
    palette: {        
        primary: {
            main: '#EDEDED'
        },
        secondary: {
            main: '#5ebd69'
        }
    }
});

export default theme;

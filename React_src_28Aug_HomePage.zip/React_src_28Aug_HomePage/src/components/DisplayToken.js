import React from 'react';

import Grid from '@material-ui/core/Grid';
import Table from '@material-ui/core/Table';
import TableHead from '@material-ui/core/TableHead';
import TableRow from '@material-ui/core/TableRow';
import TableBody from '@material-ui/core/TableBody';
import TableCell from '@material-ui/core/TableCell';


import { makeStyles } from '@material-ui/styles';

//Inline styles, only for this page
const useStyles = makeStyles({
    card: {
        width: "25%"
    },
    cardContent: {
        padding: "0px",
        // background: "green",
        height: "1.5em"
    },
    gridContainer: {
        background: "#EDEDED",
        height: "500px"  
    },
    tab: {
        textTransform: "none",
        width: "50%",
        textAlign: "center",
        background: "#E0E0E0"
    }
});


const DisplayToken = () => {
    const classes = useStyles();

    return (
        <Grid container bgColor="primary" justify="center" alignItems="center" className={classes.gridContainer} >
            <Grid item >
                <Table border="2" aria-label="simple table">
                   
                        <TableRow>
                            <TableCell colSpan="2" align="center" >Token Values</TableCell>                           
                        </TableRow>
                    
                        <TableRow>
                            <TableCell>Access Token</TableCell>
                            <TableCell align="right">A3456HJBN</TableCell>                            
                        </TableRow>
                        <TableRow>
                            <TableCell>Refresh Token</TableCell>
                            <TableCell align="right">REF3456HJBN</TableCell>
                        </TableRow>
                        <TableRow>
                            <TableCell>ID Token</TableCell>
                            <TableCell align="right">ID3456HJBN</TableCell>
                        </TableRow>
                    
                </Table>
            </Grid>
        </Grid>
    );
    }

export default DisplayToken;
import React, { useState } from 'react';
import { Link } from 'react-router-dom';

import AppBar from '@material-ui/core/AppBar';
import Toolbar from '@material-ui/core/Toolbar';
import Tabs from '@material-ui/core/Tabs';
import Tab from '@material-ui/core/Tab';
import Button from '@material-ui/core/Button';
import Menu from '@material-ui/core/Menu';
import MenuItem from '@material-ui/core/MenuItem';
import Paper from '@material-ui/core/MenuItem';
import Grid from '@material-ui/core/Grid';
import Hidden from '@material-ui/core/Hidden';
import useScrollTrigger from "@material-ui/core/useScrollTrigger";
import Slide from '@material-ui/core/Slide';

import logo from '../img/logo.svg';
import { makeStyles } from '@material-ui/styles';

function HideOnScroll(props) {
    const { children } = props;

    const trigger = useScrollTrigger({
        threshold: 50  // this sets the number of pixels which will be scrolled to hide the appbar, default is 1000
    });
    return (
        <Slide appear={false} direction="down" in={!trigger}>
            {children}
        </Slide>
    );
}
    
const useStyles = makeStyles(theme => ({
    toolbarMargin: {
        ...theme.mixins.toolbar,
        //marginBottom: "3em",
        [theme.breakpoints.down("md")]: {
            marginBottom: "2em"
        },
        [theme.breakpoints.down("xs")]: {
            marginBottom: "1.25em"
        },
        backgroundColor: "primary",
        padding:0
    },
    logo: {
        height :"8em"
    },
    
    tabContainer: {
        marginLeft:"auto",
       // width: "100%",
        hAlign: "middle",
        //textAlign: "center"
    },
    tab: {
        textTransform: "none",
        minWidth: 10,
        marginLeft: "25px"
        //width: "50%",
       // textAlign: "center",
        //background: "#E0E0E0"
    },
    button: {
        marginLeft: "35px",
        marginRight: "35px",
        textTransform: "none",
        color:"white"
    }
}));


const Header = () => {
    const authenticated = false; // set this variable to hide or show menu items
    const classes = useStyles();
    const [anchorEl, setAnchorEl] = useState(null);
    const [open, setOpen] = useState(false); // to set the visibility of menu

    // Arrow function to set the target of menu
    const handleClick = (e) => {
        setAnchorEl(e.currentTarget);
        setOpen(true);
    }
    // Arrow function to handle event of closing menu when cursor is moved away from menu
    const handleClose = (e) => {
        setAnchorEl(null);
        setOpen(false);
    }
    return (
        <React.Fragment>
        <HideOnScroll>
                <AppBar position="fixed" color="primary">
            <Toolbar disableGutters>
                <img alt="company logo" className={classes.logo}  src={logo}/>
                <Tabs className={classes.tabContainer} indicatorColor="primary">
                        <Tab className={classes.tab} label="Platform" component={Link} to="/platform" />
                        <Tab className={classes.tab} label="Pricing" component={Link} to="/pricing" />
                        <Tab
                            className={classes.tab}
                            label="Resources"
                            component={Link}
                            to="/resources" />

                        <Tab className={classes.tab} label="Company" component={Link} to="/company"/>
                </Tabs>
                    <Button
                        aria-owns={anchorEl ? "display-menu" : undefined}
                        aria-haspopup={anchorEl ? "true" : undefined}
                        onMouseOver={event => handleClick(event)}
                    variant="contained"
                    color="secondary"
                    className={classes.button} >
                        Get Started
                </Button>
                    <Paper>
                        
                    <Menu id="display-menu" anchorEl={anchorEl} open={open}
                            MenuListProps={{ onMouseLeave: handleClose }} >
                        <Hidden xsUp={authenticated} xsDown={authenticated}> 
                            <MenuItem onClick={handleClose} component={Link} to="/resources">
                                        Resources
                            </MenuItem>
                        </Hidden>  
                        <MenuItem onClick={handleClose} component={Link} to="/displayToken">
                            Display Tokens
                        </MenuItem>

                     </Menu>
                       
                    </Paper>
            </Toolbar>           
            </AppBar>
        </HideOnScroll>
        <div className={classes.toolbarMargin} />
        </React.Fragment>
    );
}

export default Header;
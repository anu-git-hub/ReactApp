import React from 'react';
import { ThemeProvider } from '@material-ui/styles';
import { BrowserRouter, Route, Switch } from 'react-router-dom';

import Header from './components/Header';
import theme from './components/Theme';
import DisplayToken from './components/DisplayToken';
import LandingPage from './components/LandingPage';

const App = ()=> {
  
    return (
        <ThemeProvider theme={theme}>
            <BrowserRouter>
                <Header /> 
                <Switch>
                    <Route exact path="/"
                        component={LandingPage} />
                    <Route exact path="/platform"
                        component={() => <div align="center" > Platform</div>} />
                    <Route exact path="/pricing"
                        component={() => <div align="center"> Pricing</div>} />
                    <Route exact path="/resources"
                        component={() => <div align="center"> Resources</div>} />
                    <Route exact path="/company"
                        component={() => <div align="center"> Company</div>} />
                    <Route exact path="/displayToken" component={DisplayToken} />
                </Switch>
                
            </BrowserRouter>
        </ThemeProvider>
    );
  
}

export default App;
